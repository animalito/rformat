library(devtools)

has_devel()
